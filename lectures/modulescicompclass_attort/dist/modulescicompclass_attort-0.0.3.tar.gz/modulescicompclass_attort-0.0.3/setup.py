from setuptools import setup, find_packages

setup(name='modulescicompclass_attort',
      description='test module for the SciComp class by Davide Gerosa, uploaded by Davide Trotta for testing out pip',
      version='0.0.3',
      packages=find_packages(),
      install_requires=['numpy', 'matplotlib'])