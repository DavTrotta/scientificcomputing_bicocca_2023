from .mandel import *  # This makes everything accessible in the top-level namespace
