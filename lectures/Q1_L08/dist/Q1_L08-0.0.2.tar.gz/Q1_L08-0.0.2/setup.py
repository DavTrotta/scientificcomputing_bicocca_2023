from setuptools import setup, find_packages

setup(name='Q1_L08',
      description='TICTACTOE by Davide Trotta',
      version='0.0.2',
      packages=find_packages(),
      install_requires=['IPython'])